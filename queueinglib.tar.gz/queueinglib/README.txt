
This is not a standalone simulation!

This directory contains a queuing library implementation; see the QueueNet
directory for an example usage.

